#!/bin/sh

module swap PrgEnv-cray PrgEnv-intel
module load ncl
module load cray-netcdf
module load wrf/3.9.1.1

FILES_DIR=$GEOG/../BC
LOKAL_FILES_DIR=$SCRATCH/WRF/CAMS

mkdir $LOKAL_FILES_DIR

for id in 20100101;do
#for id in  20081201 20090101 20090201 20090301 20090401 20090501 20090601 20090701 20090801 20090901 20091001 20091101 20091201;do

 ln -sf $FILES_DIR/AER_${id}* $LOKAL_FILES_DIR/AER_${id}_eac4_EU.nc
 ln -sf $FILES_DIR/GRG_${id}* $LOKAL_FILES_DIR/GRG_${id}_eac4_EU.nc
 ln -sf $FILES_DIR/GRG_voc_${id}* $LOKAL_FILES_DIR/GRG_voc_${id}_eac4_EU.nc
 ln -sf $FILES_DIR/PS_${id}* $LOKAL_FILES_DIR/PS_${id}_eac4_EU.nc
 #ncl fileid="${id}" indir="${FILES_DIR}" outdir="${FILES_DIR}/processed" MACC_BC2MOZART.ncl
 #ncl MACC_BC2MOZART.ncl fileid="${id}"
 ncl -x MACC_BC2MOZART.ncl fileid="${id}"

done
